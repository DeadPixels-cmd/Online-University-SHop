<header>
  <div class="page-wrapper">
  <!-- end of loader-->
 <div class="nav-wrapper">
  <div class="grad-bar"></div>
  <nav class="navbar">
    <a href = "home.php" class = "logo"><img src="/spartan shop/components/images/sample_logo.jpg" alt="Company Logo"></a>
    <div class="menu-toggle" id="mobile-menu">
      <span class="bar"></span>
      <span class="bar"></span>
      <span class="bar"></span>
    </div>
    <ul class="nav no-search">
      <li class="nav-item"><a href="home.php">Home</a></li>
      <li class="nav-item"><a href="about.php">About</a></li>
      <li class="nav-item"><a href="#">Work</a></li>
      <li class="nav-item"><a href="#">Careers</a></li>
      <li class="nav-item"><a href="contact.php">Contact Us</a></li>
      <i class="fas fa-search" id="search-icon"></i>
      <input class="search-input" type="text" placeholder="Search..">
    </ul>
  </nav>
  </div>
</div>
</header>