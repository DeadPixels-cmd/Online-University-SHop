"use strict";

// Declare variables
let radioValue;
let quantity;

// Function to get the selected radio button value
function getSelectedRadioValue() {
  const radioButton = document.querySelector('input[name="radioButtonName"]:checked');
  radioValue = radioButton ? radioButton.value : "";
}

// Function to get the quantity value
function getQuantityValue() {
  quantity = document.getElementById('quantityInput').value;
}

// Usage example
function logValues() {
  console.log("Radio value: " + radioValue);
  console.log("Quantity: " + quantity);
}

// Event listener for window load
window.addEventListener('load', function() {
  // Get the plus, minus, and number elements
  const plus = document.querySelector(".plus");
  const minus = document.querySelector(".minus");
  const num = document.querySelector(".num");

  // Set the initial value of 'a' and update number display
  let a = 1;
  insertingText();

  // Event listener for plus button
  plus.addEventListener("click", () => {
    if (a < 999) {
      a++;
      insertingText();
    }
  });

  // Event listener for minus button
  minus.addEventListener("click", () => {
    if (a > 1) {
      a--;
      insertingText();
    }
  });

  // Update the number display with the current value of 'a'
  function insertingText() {
    a = (a < 10) ? "0" + a : a;
    num.innerText = a;
  }

  // Call functions to get radio button value and quantity value
  getSelectedRadioValue();
  getQuantityValue();

  // Call the usage example function
  logValues();
});
