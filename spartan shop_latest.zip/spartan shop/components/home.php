<?php
 	include $_SERVER['DOCUMENT_ROOT'] . '/spartan shop/components/connection.php';
 ?>
 <style type="text/css">
 	<?php include 'style.css'; ?>
 </style>
<!DOCTYPE html>
<html>
<head>
	<meta charset=" UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400" rel="stylesheet"> 
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous"><link rel="stylesheet" href="./style.css">

	<link href="style.css" rel="stylesheet">
	<title>University Shop</title>
</head>
<body>
	<?php include $_SERVER['DOCUMENT_ROOT'] . '/spartan shop/components/header.php'; ?>
	<section class="headline">
    <h1>Spartan Shop</h1>
    <p>Purchase items at ease!</p>
  </section>
	<div class="main">
    <ul class="cards">
      
    
      
      <!-- Card Grid -->
      <li class="cards-item">
        <div class="card">
          <div class="card-image">
            <img src="/template/components/images/id_lace.jpg" alt="">
          </div>
          
          <div class="card-content">
            <h2 class="card-title">ID Lace</h2><br><br>
            <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur, consequatur.</p>
            <button class="btn card-btn" onClick = "window.location.href = 'view_product.php'">Buy</button>
          </div>
        </div>
      </li>

      <li class="cards-item">
        <div class="card">
          <div class="card-image">
            <img src="/spartan shop/components/images/uniform_male.png" alt="">
          </div>
          
          <div class="card-content">
            <h2 class="card-title">Uniform (M)</h2><br>
              <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur, consequatur.</p>
            <button class="btn card-btn" onClick = "window.location.href = 'view_product2.php'">Buy</button>
          </div>
        </div>
      </li>

      <li class="cards-item">
        <div class="card">
          <div class="card-image">
            <img src="/spartan shop/components/images/pe_uniform.png" alt="">
          </div>
          
          <div class="card-content">
            <h2 class="card-title">PE Uniform</h2><br>
            <p>  </p>
            <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur, consequatur.</p>
            <button class="btn card-btn" onClick = "window.location.href = '#.php'">Buy</button>
          </div>
        </div>
      </li>

      <li class="cards-item">
        <div class="card">
          <div class="card-image">
            <img src="/spartan shop/components/images/nstp_front.png" alt="">
          </div>
          
          <div class="card-content">
            <h2 class="card-title">NSTP Shirt</h2><br>
            <p></p>
            <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur, consequatur.</p>
            <button class="btn card-btn" onClick = "window.location.href = '#'">Buy</button>
          </div>
        </div>
      </li>

      <li class="cards-item">
        <div class="card">
          <div class="card-image">
            <img src="/spartan shop/components/images/bsu_towel.png" alt="">
          </div>
          
          <div class="card-content">
            <h2 class="card-title">BatStateU Towel</h2><br>
            <p></p>
            <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur, consequatur.</p>
            <button class="btn card-btn" onClick = "window.location.href = '#'">Buy</button>
          </div>
        </div>
      </li>
<!--
      <li class="cards-item">
        <div class="card">
          <div class="card-image">
            <img src="/spartan shop/components/images/item6.jpg" alt="">
          </div>
          
          <div class="card-content">
            <h2 class="card-title">lorem Ipsum</h2><br>
            <p></p>
            <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur, consequatur.</p>
            <button class="btn card-btn">Add to Cart</button>
          </div>
        </div>
      </li>

-->      
      

      <!-- card grid end -->
   </ul>
</div>
<br><br>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script type="text/javascript" src="/spartan shop/components/script.js"></script>
	<?php include $_SERVER['DOCUMENT_ROOT'] . '/spartan shop/components/alert.php'; ?>
	<?php include $_SERVER['DOCUMENT_ROOT'] . '/spartan shop/components/footer.php'; ?>
</body>
</html>
