<?php
 	include $_SERVER['DOCUMENT_ROOT'] . '/spartan shop/components/connection.php';
 ?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Receipt</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="./style4.css">

</head>
<body>
<!-- partial:index.partial.html -->
<h1 class="page-title">Thank you for Purchasing!</h1>

<article class="receipt">
	<section class="receipt__half upper">
		<p>Receipt</p>
		<h1>P 50.00</h1>
		<p class="sm">05.19.2023</p>
		
		<div class="receipt__content">
			<table>
				<tbody>
					<tr>
						<td>ID Lace (1)</td>
						<td>P 50.00</td>
					</tr>
				</tbody>
			</table>
		</div>
	</section>
	
	<section class="receipt__half lower">
		<button>More info</button>
		<button><a href="home.php">Back to Home</a></button>
	</section>
</article>
<!-- partial -->
  <script  src="/spartan shop/components/script2.js"></script>

</body>
</html>
