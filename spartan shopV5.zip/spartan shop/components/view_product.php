<?php
 	include $_SERVER['DOCUMENT_ROOT'] . '/spartan shop/components/connection.php';
 ?>
 <style type="text/css">
 	<?php include 'style.css'; ?>
 </style>
<!DOCTYPE html>
<html>
<head>
	<meta charset=" UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400" rel="stylesheet"> 
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
  <!--<link rel="stylesheet" href="./style.css"> -->-
  <link rel="stylesheet" href="./style5.css">
  
	<title>University Shop</title>
</head>

<body>
	<?php include $_SERVER['DOCUMENT_ROOT'] . '/spartan shop/components/header.php'; ?>
<main>
  <br><br>
  <div class="container">
    <div class="grid second-nav">
      <div class="column-xs-12">
      </div>
    </div>
    <div class="grid product">
      <div class="column-xs-12 column-md-7">
        <div class="product-gallery">
          <div class="product-image">
            <img class="active" src="images/id_lace.jpg">
          </div>
          <ul class="image-list">
            <li class="image-item"><img src="images/id_lace.jpg"></li>
            <li class="image-item"><img src="images/id_lace2.png"></li>
            <li class="image-item"><img src="images/id_lace2.png"></li>
          </ul>
        </div>
      </div>
      <div class="column-xs-12 column-md-5">
        <h1>ID Lace</h1>
        <h2>P50.00</h2>
        <div class="description">
          <p>Available in : Lipa, Malvar, Rosario, Pablo Borbon</p>
          <br><br><br><br><br><br><br>
          
        </div>
        <div class="center-button">
          <button class="add-to-cart" onClick="window.location.href='receipt.php'">Check Out</button>
        </div>

      </div>
      <br><br>
    </div>
    <div class="grid related-products">
      <div class="column-xs-12">
        <h3>You may also like</h3>
      </div>
      <div class="column-xs-12 column-md-4">
        <img src="images/item1.jpg">
        <h4>Uniform (Male)</h4>
        <p class="price">P1000.00</p>
      </div>
      <div class="column-xs-12 column-md-4">
        <img src="images/item2.JPG">
        <h4>Uniform (Female)</h4>
        <p class="price">P1000.00</p>
      </div>
      <div class="column-xs-12 column-md-4">
        <img src="images/item3.JPG">
        <h4>PE Uniform</h4>
        <p class="price">P950.00</p>
      </div>
    </div>
  </div>
</main>

	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script type="text/javascript" src="/spartan shop/components/script.js"></script>
	<?php include $_SERVER['DOCUMENT_ROOT'] . '/spartan shop/components/alert.php'; ?>
	<?php include $_SERVER['DOCUMENT_ROOT'] . '/spartan shop/components/footer.php'; ?>
</body>
</html>
