<?php
	
	$db_name = 'mysql:host = localhost; dbname = shop_db';
	$db_user = 'root@localhost';
	$db_password = '';

	$conn = new PDO ($db_name,$db_user,$db_password);

	if($conn){
	}

	function unique_id(){
		$chars = '01234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVEWXYZ';
		$charLength = strLen($chars);
		$randomString = '';
		for ($i=0; $i<20; $i++){
			$randomString.=$chars[mt_rand(0, $charLength - 1)];
		}
		return $randomString;
	}

?>